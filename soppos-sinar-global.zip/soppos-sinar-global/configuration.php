<?php

class SConfig{
	var $_site_url 					= "http://192.168.43.171/soppos-sinar-global/";
	var $_site_name 				= "LawaveDesign.com";
	var $_host_name 				= "localhost";
	var $_database_name 		= "db_soppos";
	var $_database_user 		= "root";
	var $_database_password = "";
	var $_table_prefix 			= "lwd_";
	var $_cms_name 					= "LawaveDesign CMS ver.1.0";
}

?>
