<?php

$this->load->view('component/top');
$this->load->view('component/header');
$this->load->view($content);
$this->load->view('component/footer');
$this->load->view('component/bottom');
