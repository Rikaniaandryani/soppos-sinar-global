			<footer class="main-footer">
				<div class="pull-right hidden-xs">
					<b>Version</b> 0.9.1
				</div>
				<strong>Copyright &copy; 2017 <a href="http://almsaeedstudio.com">LaWaveDesign.com</a>.</strong> All rights reserved.
			</footer>

		</div><!-- ./wrapper -->
