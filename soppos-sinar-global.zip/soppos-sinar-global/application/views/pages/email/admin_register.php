<table style="background-color: #ffffff; width: 100%; margin: 0 auto;">
	<tbody>
		<tr>
			<td>
				<h3 style="color: #5d9ec3;">
					Member baru dengan ID Member <strong><?php echo $member->member_id ?></strong>
				</h3>
			</td>
		</tr>
	</tbody>
</table>
