<table style="background-color: #ffffff; width: 100%; margin: 0 auto;">
	<tbody>
		<tr>
			<td>
				<h3 style="color: #5d9ec3;">
					Pesan dari pengunjung Erakomp.com
				</h3>
			</td>
		</tr>
		<tr>
			<td>
				<strong>Nama : </strong><?php echo $nama ?>
			</td>
		</tr>
		<tr>
			<td>
				<strong>Telepon : </strong><?php echo $telp ?>
			</td>
		</tr>
		<tr>
			<td>
				<strong>Email : </strong><?php echo $email ?>
			</td>
		</tr>
		<tr>
			<td>
				<strong>Pesan : </strong>
				<p>
					<?php echo $pesan ?>
				</p>
			</td>
		</tr>
	</tbody>
</table>
